# roboflow_nhanes_l1_to_l5_detection > roboflow_nhanes_l1_to_l5_no_augmentation
https://universe.roboflow.com/marcos-kantor/roboflow_nhanes_l1_to_l5_detection-npahn

Provided by a Roboflow user
License: CC BY 4.0

