# Lumbar Spine  > 2025-01-05 4:54pm
https://universe.roboflow.com/rp-team/lumbar-spine-vpxwf

Provided by a Roboflow user
License: CC BY 4.0

